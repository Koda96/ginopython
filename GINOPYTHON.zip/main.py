import montos
import empleados

if __name__ == "__main__":
    #montos.ventas()
    print(empleados.run())