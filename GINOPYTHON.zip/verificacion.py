def esEntero(dato):
    if (type(dato) == int):
        return True
    else:
        return False
    
def esNegativo(dato):
    if (dato < 0):
        return False
    else:
        return True